import React, { useRef, useState } from "react";
import "./HomePage1.css";
import Payment from "./Payment";
import ImageSlider from "./ImageSlider"; // ✅ Import your slider component here

function HomePage1() {
  const [showPayment, setShowPayment] = useState(false);
  const aboutRef = useRef(null);
  const eventsRef = useRef(null);

  const handleDonateClick = () => {
    setShowPayment(true);
  };

  const handleClose = () => {
    setShowPayment(false);
  };

  const scrollToAbout = () => {
    aboutRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const scrollToImageSlider = () => {
    eventsRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div>
      {/* Hero Section */}
      <div
        className="container"
        style={{
          background:
            'linear-gradient(rgba(29, 90, 140, 0.7), rgba(29, 90, 140, 0.7)), url("/arn.jpg") center/cover no-repeat',
        }}
      >
        <nav className="nav">
          <div className="logoSection">
            <div className="logo">
              <img src="/sevauk logo.jpg" alt="Sevauk Logo" />
            </div>
            <div className="logo">
              <img src="/logo22.jpg" alt="Arunodaya Logo" />
            </div>
            <span className="title">ARUNODAYA</span>
          </div>

          <div className="navLinks">
            <a href="#">Home</a>
            <a className="linkBtn" onClick={scrollToAbout}>About</a>
            <a className="linkBtn" onClick={scrollToImageSlider}>Events</a>
            <button className="loginBtn" onClick={handleDonateClick}>
              Donate Us
            </button>
          </div>
        </nav>

        <div className="contentCenter">
          <div className="slogan">
            <span>BEHIND EVERY STEP OUR CHILDREN TAKE</span>
            <br />
            <span>THERE ARE HANDS THAT HOLD, HEARTS THAT CARE,</span>
            <br />
            <span>AND WHO BELIEVE IN THEIR POTENTIAL.</span>
          </div>
          <button
            className="enrollBtn"
            onClick={() => (window.location.href = "#contact")}
          >
            Contact Us
          </button>
        </div>

        <button className="donateSticky" onClick={handleDonateClick}>
          Donate Us
        </button>

        {/* Payment Modal */}
        {showPayment && (
          <div className="paymentModal">
            <div className="modalOverlay" onClick={handleClose}></div>
            <div className="slideUpModal">
              <div className="modalHeader">
                <h2>Donate to Arunodaya</h2>
                <button className="closeBtn" onClick={handleClose}>×</button>
              </div>
              <div className="modalBody">
                <Payment />
              </div>
            </div>
          </div>
        )}
      </div>
      {/* Vision */}
      <br></br>
      <div className="vision-section">
        <div className="school-heading">Vision</div>
        <div className="school-text-center school-mb-40">
          Our vision is rooted in providing a blend of home-based emotional care
          and professionally guided special Training/ Education and therapy.
        </div>
      </div>
       {/* Mission */}
      <div className="school-mission-section">
        <div className="school-mission-text">
          <div className="school-subheading">Our Mission</div>
          <div>
            To provide a high-quality education that nurtures the holistic
            development of students.
            <br />
            <br />
            To help students develop into responsible and responsive global
            citizens with strong moral values and an understanding of diverse
            cultures.
          </div>
        </div>
        <div className="school-diagram">
          <img
            src="/diagram.jpg"
            alt="Mission Diagram"
            className="school-diagram-image"
          />
        </div>
        </div>

      {/* About Section */}
      <div ref={aboutRef} className="about-section">
        <h2 className="school-subheading">About Us</h2>
        <p className="school-about-text">
          Arunodaya Special School began its journey in a small rented room with just 8–12 students, supported by three passionate faculty members and limited resources. What started as a humble initiative has today grown into a recognized institution for children with special needs in Gadag.

The school is currently training 42 children, while more than 120 parents seek counselling and guidance from the team. Over the years, Arunodaya has trained 183 children, with 29 successfully integrated into mainstream schools. Among them, one proud student went on to complete a postgraduate degree in Social Work — a milestone that reflects the school’s vision and impact.

Arunodaya strongly believes in holistic development. Children here are nurtured not only through academics but also through arts, physical education, medical support, and specialized therapies. The focus is on empowering each child to achieve independence, confidence, and dignity in life.

The school is equally committed to supporting families by providing counselling, awareness programs, and guidance to parents of special children. This two-way approach strengthens both the child’s and the family’s journey.

Over time, Arunodaya has built a strong reputation for its social service and inclusive education model. With the continued support of well-wishers, community members, and organizations like Seva Bharati and Seva UK, the school remains steadfast in its mission — to provide every child with special needs a nurturing, inclusive, and hopeful future.
          {/* Full about us content here */}
        </p>
        <hr className="school-hr" />
      </div>

      {/* Events Section */}
      <div ref={eventsRef} className="events-section">
        <h2 className="school-subheading">Our Events</h2>
        <ImageSlider />
        <hr className="school-hr" />
      </div>
    </div>
  );
}

export default HomePage1;
