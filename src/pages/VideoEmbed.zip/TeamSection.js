import React, { useState } from "react";
import "./TeamSection.css";

const founders = [
  { name: "Anand Krishnan", role: "Founder", image: "/edit1.jpg" },
  { name: "Sujata Satyamadhava", role: "Founder", image: "/edit2.jpg" },
  { name: "Jyoti Rajappa", role: "HR, Finance & Administration", image: "/edit3.jpg" },
  { name: "Priya Vijayan", role: "Academics", image: "/edit4.jpg" },
];

const governors = [
  { name: "Jyoti Rajappa", role: "Governor", image: "/edit6.jpg" },
  { name: "Priya Vijayan", role: "Governor", image: "/edit5.jpg" },
];

const teamMembers = [
  { name: "Anand Krishnan", role: "Projects and CSR", image: "/edit7.jpg" },
  { name: "Sujata Satyamadhava", role: "Family Services", image: "/edit8.jpg" },
  { name: "Jyoti Rajappa", role: "HR, Finance & Administration", image: "/edit9.jpg" },
  { name: "Priya Vijayan", role: "Academics", image: "/edit10.jpg" },
];

export default function TeamSection() {
  const [tab, setTab] = useState("TEAM");

  let people;
  switch (tab) {
    case "FOUNDERS":
      people = founders;
      break;
    case "GOVERNORS":
      people = governors;
      break;
    default:
      people = teamMembers;
  }

  return (
    <div className="team-container">
      <h1 className="team-title">TEAM</h1>
      <div className="team-inner">
        <div className="team-tabs">
          {["FOUNDERS", "GOVERNORS", "TEAM"].map((t) => (
            <div
              key={t}
              className={`team-tab ${tab === t ? "team-tab-active" : ""}`}
              onClick={() => setTab(t)}
              style={{ cursor: "pointer" }}
            >
              {t}
            </div>
          ))}
        </div>
        <div className="team-members">
          {people.map((tm) => (
            <div key={tm.name} className="team-member">
              <div className="team-member-image">
                <img
                  src={tm.image}
                  alt={tm.name}
                  style={{
                    width: "100%",
                    height: "100%",
                    objectFit: "cover",
                    borderRadius: "20px",
                  }}
                />
              </div>
              <div className="team-member-name">{tm.name}</div>
              <div className="team-member-role">{tm.role}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}